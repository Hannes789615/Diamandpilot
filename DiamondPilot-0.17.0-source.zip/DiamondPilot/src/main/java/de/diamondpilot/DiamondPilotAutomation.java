package de.diamondpilot;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import java.util.HashSet;
import java.util.Set;

/**
 * Conservative client-side tunnel/mining state machine.
 * It only interacts with blocks already known to the client and stops on hazards.
 */
public final class DiamondPilotAutomation {
    private enum Mode { TUNNEL, MINE_DIAMOND, WAITING }

    private Mode mode = Mode.TUNNEL;
    private BlockPos currentTarget;
    private int targetTicks;
    private boolean targetWasActivelyMined;
    private int failedTargets;
    private int minedThisRun;
    private int retreatTicks;
    private int noProgressTicks;
    private int stuckTurnAttempts;
    private BlockPos lastProgressPosition;
    private Direction tunnelDirection = Direction.SOUTH;
    private float startYaw;
    private final Set<BlockPos> blockedTargets = new HashSet<>();

    public void start(Minecraft client, DiamondPilotConfig config) {
        if (client.player == null || client.level == null) return;
        tunnelDirection = cardinalFromYaw(client.player.getYRot());
        noProgressTicks = 0;
        stuckTurnAttempts = 0;
        lastProgressPosition = client.player.blockPosition().immutable();
        // Snap the actual view yaw to the same cardinal direction used by tunnel checks.
        startYaw = tunnelDirection.toYRot();
        client.player.setYRot(startYaw);
        client.player.setXRot(0.0f);
        mode = Mode.TUNNEL;
        currentTarget = null;
        targetTicks = 0;
        failedTargets = 0;
        blockedTargets.clear();
        retreatTicks = 0;
        config.active = true;
        config.paused = false;
        config.status = "Gestartet – Tunnelrichtung " + tunnelDirection.getName();
        config.lastPosition = client.player.blockPosition().toShortString();
        config.save();
    }

    public void stop(Minecraft client, DiamondPilotConfig config, String reason) {
        releaseInputs(client);
        if (client.gameMode != null) client.gameMode.stopDestroyBlock();
        config.active = false;
        config.paused = false;
        config.status = reason;
        config.save();
        currentTarget = null;
        mode = Mode.WAITING;
    }

    public void tick(Minecraft client, DiamondPilotConfig config, DiamondScanner scanner) {
        if (client.player == null || client.level == null || client.gameMode == null) {
            stop(client, config, "Gestoppt – keine Weltverbindung");
            return;
        }
        if (!config.active || config.paused) {
            releaseInputs(client);
            return;
        }

        var player = client.player;
        BlockPos here = player.blockPosition();
        config.lastPosition = here.toShortString();
        if (lastProgressPosition == null || !lastProgressPosition.equals(here)) {
            lastProgressPosition = here.immutable();
            noProgressTicks = 0;
            stuckTurnAttempts = 0;
        } else if (mode == Mode.TUNNEL && currentTarget == null) {
            noProgressTicks++;
            if (noProgressTicks >= 80) {
                if (stuckTurnAttempts >= 3) {
                    stop(client, config, "Gestoppt – in mehreren Richtungen festgesteckt; bitte manuell prüfen");
                    return;
                }
                tunnelDirection = tunnelDirection.getClockWise();
                startYaw = tunnelDirection.toYRot();
                player.setYRot(startYaw);
                player.setXRot(0.0f);
                stuckTurnAttempts++;
                noProgressTicks = 0;
                config.status = "Feststecken erkannt – probiere einen anderen Tunnelweg (" + stuckTurnAttempts + "/3)";
            }
        }

        if (player.isInLava() || player.isInWater() || hasFluidHazard(client, here)) {
            stop(client, config, "SICHERHEITSSTOPP – Wasser oder Lava in der Nähe; bitte prüfen");
            return;
        }
        var nearbyMonsters = client.level.getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(7.0));
        if (!nearbyMonsters.isEmpty()) {
            // Keep safety checks active and retreat instead of attacking or mining near a hostile mob.
            var threat = nearbyMonsters.stream().min(java.util.Comparator.comparingDouble(player::distanceToSqr)).orElse(null);
            if (threat != null) {
                double dx = player.getX() - threat.getX();
                double dz = player.getZ() - threat.getZ();
                float awayYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
                Direction retreatDirection = Direction.fromYRot(awayYaw);
                BlockPos retreatFeet = here.relative(retreatDirection);
                BlockPos retreatHead = retreatFeet.above();
                BlockPos retreatFloor = retreatFeet.below();
                boolean safeRetreat = client.level.hasChunkAt(retreatFeet)
                        && client.level.hasChunkAt(retreatHead)
                        && client.level.hasChunkAt(retreatFloor)
                        && client.level.getBlockState(retreatFeet).isAir()
                        && client.level.getBlockState(retreatHead).isAir()
                        && client.level.getFluidState(retreatFeet).isEmpty()
                        && client.level.getFluidState(retreatHead).isEmpty()
                        && client.level.getBlockState(retreatFloor).isSolid()
                        && client.level.getFluidState(retreatFloor).isEmpty();
                releaseAttack(client);
                client.options.keyJump.setDown(false);
                client.options.keySprint.setDown(false);
                if (!safeRetreat) {
                    stop(client, config, "SICHERHEITSSTOPP – Monster in der Nähe, kein sicherer Rückweg");
                    return;
                }
                // Move along the same cardinal direction that was safety-checked.
                player.setYRot(retreatDirection.toYRot());
                player.setXRot(0.0f);
                client.options.keyUp.setDown(true);
                config.status = "Gefahr – entferne mich auf sicherem Boden von einem Monster";
                return;
            }
        }
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty() || !(held.getItem() instanceof PickaxeItem)) {
            stop(client, config, "Gestoppt – halte eine Spitzhacke in der Haupthand");
            return;
        }
        if (isToolNearBreak(held, config.durabilityThreshold)) {
            stop(client, config, "Gestoppt – Werkzeug erreicht die Haltbarkeitsgrenze");
            return;
        }
        if (player.getInventory().getFreeSlot() == -1 && !dropOneStoneStack(client)) {
            stop(client, config, "Gestoppt – Inventar voll und kein Stein zum Ablegen; bitte Inventar leeren");
            return;
        }

        // Scan in small increments so the UI and safety checks continue to run.
        scanner.tick(client, config);

        BlockPos diamond = nearestDiamond(client, scanner, here, config.searchRadius);
        if (diamond != null) {
            mode = Mode.MINE_DIAMOND;
            double distance = diamond.distToCenterSqr(player.getX(), player.getEyeY(), player.getZ());
            if (distance <= 4.5 * 4.5 && canSeeTargetBlock(client, diamond)) {
                mineTarget(client, config, diamond, true);
            } else {
                approachDiamond(client, config, diamond, here);
            }
            return;
        }

        mode = Mode.TUNNEL;
        tunnelForward(client, config, here);
    }

    private void tunnelForward(Minecraft client, DiamondPilotConfig config, BlockPos here) {
        BlockPos feet = here.relative(tunnelDirection);
        BlockPos head = feet.above();
        BlockPos aboveHead = head.above();

        // Make a two-block-high, one-block-wide tunnel. Clear only the next cell.
        BlockPos obstruction = null;
        if (!client.level.getBlockState(feet).isAir()) obstruction = feet;
        else if (!client.level.getBlockState(head).isAir()) obstruction = head;
        // Leave the roof above the requested two-block tunnel untouched.

        if (obstruction != null) {
            BlockState state = client.level.getBlockState(obstruction);
            if (isProtectedOrHazardous(state)) {
                stop(client, config, "Gestoppt – unsicherer oder nicht abbaubarer Block vor dem Tunnel");
                return;
            }
            mineTarget(client, config, obstruction, false);
            return;
        }

        // Never walk blindly into an unloaded chunk, a fluid, or an unsupported cell.
        if (!client.level.hasChunkAt(feet) || !client.level.hasChunkAt(feet.below())) {
            stop(client, config, "Sicherheitsstopp – Tunnelende erreicht; nächster Bereich ist nicht geladen");
            return;
        }
        BlockPos floor = feet.below();
        BlockState floorState = client.level.getBlockState(floor);
        if (!floorState.isSolid() || !floorState.getFluidState().isEmpty()
                || !client.level.getFluidState(feet).isEmpty()
                || !client.level.getFluidState(head).isEmpty()) {
            stop(client, config, "Sicherheitsstopp – kein sicherer Boden oder Flüssigkeit vor dem Tunnel");
            return;
        }
        releaseAttack(client);
        faceTunnel(client);
        client.options.keyUp.setDown(true);
        client.options.keySprint.setDown(false);
        config.status = "Grabe geradeaus – Diamanten werden laufend gesucht";
    }

    private void mineTarget(Minecraft client, DiamondPilotConfig config, BlockPos target, boolean diamondOnly) {
        releaseForward(client);
        if (currentTarget == null || !currentTarget.equals(target)) {
            currentTarget = target.immutable();
            targetTicks = 0;
            targetWasActivelyMined = false;
            failedTargets = 0;
            if (client.gameMode != null) client.gameMode.stopDestroyBlock();
        }
        targetTicks++;
        if (!client.level.hasChunkAt(target)) {
            blockedTargets.add(target.immutable());
            currentTarget = null;
            releaseAttack(client);
            releaseInputs(client);
            config.status = "Ader übersprungen – Chunk nicht geladen";
            return;
        }
        BlockState state = client.level.getBlockState(target);
        if (state.isAir()) {
            if (diamondOnly && targetWasActivelyMined) {
                config.diamondBlocksMined++;
                minedThisRun++;
                DiamondPilotClient.SCANNER.forget(target, config);
                config.save();
            }
            blockedTargets.remove(target);
            currentTarget = null;
            targetTicks = 0;
            targetWasActivelyMined = false;
            releaseAttack(client);
            config.status = diamondOnly ? "Diamantenerz abgebaut" : "Tunnelblock entfernt";
            return;
        }
        if (diamondOnly && !isDiamond(state)) {
            currentTarget = null;
            releaseAttack(client);
            return;
        }
        if (isProtectedOrHazardous(state)) {
            blockedTargets.add(target.immutable());
            currentTarget = null;
            releaseAttack(client);
            config.status = "Ader übersprungen – Block nicht sicher abbaubar";
            return;
        }
        aimAt(client, target);
        beginOrContinueBreaking(client, target);
        if (diamondOnly) targetWasActivelyMined = true;
        config.status = diamondOnly ? "Baue Diamant ab: " + target.toShortString() : "Grabe: " + target.toShortString();

        // A target that has not changed after a while may be out of reach or protected by the server.
        if (targetTicks > 100) {
            blockedTargets.add(target.immutable());
            currentTarget = null;
            releaseAttack(client);
            config.status = "Diamant nicht erreichbar – markiert und Tunnel wird fortgesetzt";
        }
    }

    private void beginOrContinueBreaking(Minecraft client, BlockPos target) {
        if (client.gameMode == null || client.player == null) return;
        if (!client.gameMode.isDestroying()) {
            client.gameMode.startDestroyBlock(target, Direction.getNearest(
                    client.player.getX() - (target.getX() + 0.5),
                    client.player.getY() - (target.getY() + 0.5),
                    client.player.getZ() - (target.getZ() + 0.5)));
        } else {
            client.gameMode.continueDestroyBlock(target, Direction.getNearest(
                    client.player.getX() - (target.getX() + 0.5),
                    client.player.getY() - (target.getY() + 0.5),
                    client.player.getZ() - (target.getZ() + 0.5)));
        }
    }

    /** True only if the client's current block ray reaches the ore without an intervening block. */
    private boolean canSeeTargetBlock(Minecraft client, BlockPos target) {
        if (client.player == null || client.level == null || !client.level.hasChunkAt(target)) return false;
        var eye = client.player.getEyePosition();
        var center = target.getCenter();
        BlockHitResult hit = client.level.clip(new ClipContext(eye, center,
                ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, client.player));
        return hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(target);
    }

    /**
     * Pick the largest currently-known diamond vein first. Adjacent diamond blocks
     * are grouped in a 3x3x3 neighborhood; ties go to the nearest reachable candidate.
     * Only client-loaded block data is considered.
     */
    private BlockPos nearestDiamond(Minecraft client, DiamondScanner scanner, BlockPos from, int radius) {
        Set<BlockPos> candidates = new HashSet<>();
        double maxDistance = (double) radius * radius;
        for (BlockPos pos : scanner.foundBlocks()) {
            if (blockedTargets.contains(pos) || !client.level.hasChunkAt(pos)) continue;
            if (!isDiamond(client.level.getBlockState(pos))) continue; // stale scan result
            double dx = pos.getX() + 0.5 - from.getX();
            double dy = pos.getY() + 0.5 - from.getY();
            double dz = pos.getZ() + 0.5 - from.getZ();
            if (dx * dx + dy * dy + dz * dz <= maxDistance) candidates.add(pos.immutable());
        }
        if (candidates.isEmpty()) return null;

        Set<BlockPos> unvisited = new HashSet<>(candidates);
        Set<BlockPos> bestVein = Set.of();
        double bestDistance = Double.MAX_VALUE;
        while (!unvisited.isEmpty()) {
            BlockPos seed = unvisited.iterator().next();
            Set<BlockPos> vein = new HashSet<>();
            java.util.ArrayDeque<BlockPos> queue = new java.util.ArrayDeque<>();
            queue.add(seed);
            unvisited.remove(seed);
            while (!queue.isEmpty()) {
                BlockPos current = queue.removeFirst();
                vein.add(current);
                for (int x = -1; x <= 1; x++) for (int y = -1; y <= 1; y++) for (int z = -1; z <= 1; z++) {
                    if (x == 0 && y == 0 && z == 0) continue;
                    BlockPos neighbor = current.offset(x, y, z);
                    if (unvisited.remove(neighbor)) queue.addLast(neighbor);
                }
            }
            double distance = vein.stream().mapToDouble(p -> p.distToCenterSqr(
                    client.player.getX(), client.player.getEyeY(), client.player.getZ())).min().orElse(Double.MAX_VALUE);
            if (vein.size() > bestVein.size() || (vein.size() == bestVein.size() && distance < bestDistance)) {
                bestVein = vein;
                bestDistance = distance;
            }
        }
        return bestVein.stream().min(java.util.Comparator.comparingDouble(p -> p.distToCenterSqr(
                client.player.getX(), client.player.getEyeY(), client.player.getZ())))
                .map(BlockPos::immutable).orElse(null);
    }

    /**
     * Navigate toward a discovered vein using a bounded breadth-first search through
     * already-loaded, walkable cells. The planner never crosses fluid, drops, or
     * unloaded chunks. If no safe corridor exists, it falls back to the conservative
     * straight-line tunnelling behavior below.
     */
    private void approachDiamond(Minecraft client, DiamondPilotConfig config, BlockPos target, BlockPos here) {
        var player = client.player;
        if (player == null) return;

        BlockPos step = findSafePathStep(client, here, target);
        if (step != null && !step.equals(here)) {
            double dx = step.getX() + 0.5 - player.getX();
            double dz = step.getZ() + 0.5 - player.getZ();
            float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            yaw = Direction.fromYRot(yaw).toYRot();
            player.setYRot(yaw);
            player.setXRot(0.0f);
            releaseAttack(client);
            client.options.keyJump.setDown(step.getY() > here.getY());
            client.options.keyUp.setDown(true);
            client.options.keySprint.setDown(false);
            config.status = "Suche sicheren Weg zur Diamantader: " + target.toShortString();
            return;
        }

        // No safe existing corridor: only clear the next cell on a direct approach.
        int dy = target.getY() - here.getY();
        if (Math.abs(dy) > 2) {
            blockedTargets.add(target.immutable());
            releaseInputs(client);
            config.status = "Ader übersprungen – Höhenunterschied zu groß für sicheren Weg";
            return;
        }

        double dx = target.getX() + 0.5 - player.getX();
        double dz = target.getZ() + 0.5 - player.getZ();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        Direction direction = Direction.fromYRot(yaw);
        yaw = direction.toYRot();
        player.setYRot(yaw);
        player.setXRot(0.0f);
        BlockPos nextFeet = here.relative(direction);
        BlockPos nextHead = nextFeet.above();
        BlockPos nextFloor = nextFeet.below();
        if (!client.level.hasChunkAt(nextFeet) || !client.level.hasChunkAt(nextHead)
                || !client.level.hasChunkAt(nextFloor)) {
            stop(client, config, "Sicherheitsstopp – Weg zur Ader führt in einen nicht geladenen Bereich");
            return;
        }
        if (!client.level.getFluidState(nextFeet).isEmpty()
                || !client.level.getFluidState(nextHead).isEmpty()
                || !client.level.getFluidState(nextFloor).isEmpty()) {
            stop(client, config, "SICHERHEITSSTOPP – Flüssigkeit auf dem Weg zur Diamantader");
            return;
        }
        if (!client.level.getBlockState(nextFloor).isSolid()) {
            blockedTargets.add(target.immutable());
            releaseInputs(client);
            config.status = "Ader übersprungen – kein sicherer Boden auf direktem Weg";
            return;
        }

        BlockPos obstruction = null;
        BlockState feetState = client.level.getBlockState(nextFeet);
        BlockState headState = client.level.getBlockState(nextHead);
        if (!feetState.isAir() && !feetState.canBeReplaced()) obstruction = nextFeet;
        else if (!headState.isAir() && !headState.canBeReplaced()) obstruction = nextHead;

        if (obstruction != null) {
            BlockState state = client.level.getBlockState(obstruction);
            if (isProtectedOrHazardous(state)) {
                blockedTargets.add(target.immutable());
                releaseInputs(client);
                config.status = "Ader übersprungen – unsicherer Block versperrt den Weg";
                return;
            }
            mineTarget(client, config, obstruction, false);
            config.status = "Grabe zur Diamantader: " + obstruction.toShortString();
            return;
        }

        releaseAttack(client);
        client.options.keyJump.setDown(dy > 0);
        client.options.keyUp.setDown(true);
        client.options.keySprint.setDown(false);
        config.status = "Gehe zur Diamantader: " + target.toShortString();
    }

    /**
     * Finds the first step toward a reachable cell next to the ore. Search is limited
     * to a 25x5x25 local volume to keep each client tick bounded. Solid blocks are not
     * treated as walkable; the fallback above may tunnel through ordinary obstacles.
     */
    private BlockPos findSafePathStep(Minecraft client, BlockPos start, BlockPos ore) {
        if (client.level == null || !client.level.hasChunkAt(start) || !client.level.hasChunkAt(ore)) return null;
        java.util.ArrayDeque<BlockPos> queue = new java.util.ArrayDeque<>();
        java.util.Map<BlockPos, BlockPos> parent = new java.util.HashMap<>();
        BlockPos root = start.immutable();
        queue.add(root);
        parent.put(root, root);
        BlockPos goal = null;
        int[][] horizontal = {{1,0,0},{-1,0,0},{0,0,1},{0,0,-1}};
        int examined = 0;

        while (!queue.isEmpty() && examined++ < 2400) {
            BlockPos current = queue.removeFirst();
            if (Math.abs(current.getX() - ore.getX()) <= 1
                    && Math.abs(current.getY() - ore.getY()) <= 1
                    && Math.abs(current.getZ() - ore.getZ()) <= 1) {
                goal = current;
                break;
            }
            for (int[] d : horizontal) {
                for (int vertical : new int[]{0, 1, -1}) {
                    BlockPos next = current.offset(d[0], vertical, d[2]);
                    if (Math.abs(next.getX() - start.getX()) > 12
                            || Math.abs(next.getZ() - start.getZ()) > 12
                            || Math.abs(next.getY() - start.getY()) > 2
                            || parent.containsKey(next)
                            || !client.level.hasChunkAt(next)
                            || !isWalkable(client, next)) continue;
                    parent.put(next, current);
                    queue.addLast(next);
                }
            }
        }
        if (goal == null || goal.equals(root)) return null;
        BlockPos cursor = goal;
        BlockPos previous = parent.get(cursor);
        while (previous != null && !previous.equals(root) && !previous.equals(cursor)) {
            cursor = previous;
            previous = parent.get(cursor);
        }
        return cursor.immutable();
    }

    private boolean isWalkable(Minecraft client, BlockPos feet) {
        if (client.level == null || !client.level.hasChunkAt(feet) || !client.level.hasChunkAt(feet.above())) return false;
        BlockState feetState = client.level.getBlockState(feet);
        BlockState headState = client.level.getBlockState(feet.above());
        BlockState floorState = client.level.getBlockState(feet.below());
        if ((!feetState.isAir() && !feetState.canBeReplaced())
                || (!headState.isAir() && !headState.canBeReplaced())) return false;
        if (!feetState.getFluidState().isEmpty() || !headState.getFluidState().isEmpty()) return false;
        return floorState.isSolid() && floorState.getFluidState().isEmpty();
    }

    private boolean hasFluidHazard(Minecraft client, BlockPos here) {
        for (int forward = 1; forward <= 3; forward++) {
            BlockPos base = here.relative(tunnelDirection, forward);
            for (int dy = -1; dy <= 2; dy++) {
                BlockPos p = base.offset(0, dy, 0);
                if (!client.level.hasChunkAt(p)) continue;
                FluidState fluid = client.level.getFluidState(p);
                if (!fluid.isEmpty()) return true;
                if (client.level.getBlockState(p).is(Blocks.LAVA) || client.level.getBlockState(p).is(Blocks.WATER)) return true;
            }
        }
        return false;
    }


    /** Free one slot only by discarding common stone blocks; never discard ores, tools, or valuables. */
    private boolean dropOneStoneStack(Minecraft client) {
        if (client.player == null) return false;
        var inventory = client.player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.isEmpty()) continue;
            if (!(stack.is(Blocks.STONE.asItem()) || stack.is(Blocks.COBBLESTONE.asItem())
                    || stack.is(Blocks.DEEPSLATE.asItem()) || stack.is(Blocks.COBBLED_DEEPSLATE.asItem()))) continue;
            ItemStack discarded = inventory.removeItemNoUpdate(i);
            if (!discarded.isEmpty()) {
                client.player.drop(discarded, true);
                return inventory.getFreeSlot() != -1;
            }
        }
        return false;
    }

    private boolean isToolNearBreak(ItemStack stack, int thresholdPercent) {
        if (stack.isEmpty() || !stack.isDamageableItem()) return false;
        int remaining = stack.getMaxDamage() - stack.getDamageValue();
        return remaining <= Math.ceil(stack.getMaxDamage() * (thresholdPercent / 100.0));
    }

    private boolean isProtectedOrHazardous(BlockState state) {
        return state.isAir() || state.is(Blocks.BEDROCK) || state.is(Blocks.BARRIER)
                || state.is(Blocks.LAVA) || state.is(Blocks.WATER)
                || !state.getFluidState().isEmpty() ;
    }

    private boolean isDiamond(BlockState state) {
        return state.is(Blocks.DIAMOND_ORE) || state.is(Blocks.DEEPSLATE_DIAMOND_ORE);
    }

    private void aimAt(Minecraft client, BlockPos target) {
        var player = client.player;
        if (player == null) return;
        double dx = target.getX() + 0.5 - player.getX();
        double dy = target.getY() + 0.5 - player.getEyeY();
        double dz = target.getZ() + 0.5 - player.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        player.setYRot(yaw);
        player.setXRot(Math.max(-89.0f, Math.min(89.0f, pitch)));
    }

    private void faceTunnel(Minecraft client) {
        if (client.player == null) return;
        client.player.setYRot(startYaw);
        client.player.setXRot(0.0f);
    }

    private Direction cardinalFromYaw(float yaw) {
        return Direction.fromYRot(yaw);
    }

    public void releaseInputs(Minecraft client) {
        releaseForward(client);
        releaseAttack(client);
        if (client.options != null) client.options.keyJump.setDown(false);
    }

    private void releaseForward(Minecraft client) {
        if (client.options != null) {
            client.options.keyUp.setDown(false);
            client.options.keySprint.setDown(false);
        }
    }

    private void releaseAttack(Minecraft client) {
        if (client.gameMode != null && client.gameMode.isDestroying()) client.gameMode.stopDestroyBlock();
    }
}
