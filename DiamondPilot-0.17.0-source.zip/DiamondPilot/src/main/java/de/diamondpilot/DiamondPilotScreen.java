package de.diamondpilot;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** DiamondPilot control panel. Mining and X-Ray are experimental; test in a backup world. */
public final class DiamondPilotScreen extends Screen {
    private final DiamondPilotConfig config = DiamondPilotConfig.get();

    public DiamondPilotScreen() {
        super(Component.literal("DiamondPilot"));
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int left = center - 154;
        int right = center + 4;
        int y = Math.max(72, this.height / 2 - 82);
        int w = 150;
        int h = 20;
        int gap = 24;

        this.addRenderableWidget(Button.builder(Component.literal("Start"), b -> start()).bounds(left, y, w, h).build());
        this.addRenderableWidget(Button.builder(Component.literal(config.paused ? "Fortsetzen" : "Pause"), b -> pauseResume()).bounds(right, y, w, h).build());
        this.addRenderableWidget(Button.builder(Component.literal("STOP sofort"), b -> stop()).bounds(left, y + gap, w, h).build());
        this.addRenderableWidget(Button.builder(Component.literal(config.xrayEnabled ? "X-Ray: AN" : "X-Ray: AUS"), b -> toggleXray()).bounds(right, y + gap, w, h).build());
        this.addRenderableWidget(Button.builder(Component.literal("Radius − 8"), b -> adjustRadius(-8)).bounds(left, y + gap * 2, w, h).build());
        this.addRenderableWidget(Button.builder(Component.literal("Radius + 8 (max 96)"), b -> adjustRadius(8)).bounds(right, y + gap * 2, w, h).build());
        this.addRenderableWidget(Button.builder(Component.literal("Haltbarkeit − 5%"), b -> adjustDurability(-5)).bounds(left, y + gap * 3, w, h).build());
        this.addRenderableWidget(Button.builder(Component.literal("Haltbarkeit + 5%"), b -> adjustDurability(5)).bounds(right, y + gap * 3, w, h).build());
        this.addRenderableWidget(Button.builder(Component.literal("Erkundete Bereiche: " + config.exploredAreas), b -> {}).bounds(left, y + gap * 4, w, h).build());
        this.addRenderableWidget(Button.builder(Component.literal("Schließen"), b -> this.onClose()).bounds(right, y + gap * 4, w, h).build());
    }

    private void start() {
        if (this.minecraft.player == null || this.minecraft.level == null) return;
        DiamondPilotClient.AUTOMATION.start(this.minecraft, config);
        DiamondPilotClient.SCANNER.reset(this.minecraft, config.searchRadius);
        config.save();
    }

    private void pauseResume() {
        if (!config.active && !config.paused) return;
        config.paused = !config.paused;
        config.active = !config.paused;
        config.status = config.paused ? "Paused" : "Diamanterz-Suche gestartet";
        config.save();
        this.minecraft.setScreen(new DiamondPilotScreen());
    }

    private void stop() {
        DiamondPilotClient.AUTOMATION.stop(this.minecraft, config, "Sofort gestoppt");
        config.save();
        this.minecraft.setScreen(new DiamondPilotScreen());
    }

    private void toggleXray() {
        config.xrayEnabled = !config.xrayEnabled;
        config.status = config.xrayEnabled
                ? "X-Ray aktiv – normale Blockmodelle ausgeblendet"
                : "X-Ray deaktiviert – normale Blockmodelle sichtbar";
        config.save();
        // Block render shapes are baked into chunk meshes; request a rebuild so the toggle
        // takes effect immediately rather than waiting for chunks to be reloaded naturally.
        if (this.minecraft.levelRenderer != null) this.minecraft.levelRenderer.allChanged();
        this.minecraft.setScreen(new DiamondPilotScreen());
    }

    private void adjustRadius(int amount) {
        config.searchRadius = Math.max(8, Math.min(96, config.searchRadius + amount));
        config.save();
        this.minecraft.setScreen(new DiamondPilotScreen());
    }

    private void adjustDurability(int amount) {
        config.durabilityThreshold = Math.max(1, Math.min(100, config.durabilityThreshold + amount));
        config.save();
        this.minecraft.setScreen(new DiamondPilotScreen());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        graphics.centeredText(this.font, Component.literal("DiamondPilot"), this.width / 2, 22, 0xFF65E572);
        graphics.centeredText(this.font, Component.literal("Status: " + config.status), this.width / 2, 39, 0xFFFFFFFF);
        graphics.centeredText(this.font, Component.literal("Suchradius: " + config.searchRadius + " Blöcke  |  Werkzeug-Stopp: " + config.durabilityThreshold + "%"), this.width / 2, 53, 0xFFCCCCCC);
        graphics.centeredText(this.font, Component.literal("Gefunden: " + config.diamondsFound + "  |  Abgebaut: " + config.diamondBlocksMined), this.width / 2, this.height - 37, 0xFFFFFFFF);
        graphics.centeredText(this.font, Component.literal("Distanz: " + (long) config.distanceTravelled + " Blöcke | Scan: " + config.scannedBlockPositions + " Blöcke"), this.width / 2, this.height - 23, 0xFFCCCCCC);
        graphics.centeredText(this.font, Component.literal("X-Ray blendet normale Blockmodelle aus; Automatik experimentell."), this.width / 2, this.height - 11, 0xFFFFC857);
        graphics.centeredText(this.font, Component.literal("Letzter Fund: " + config.lastFoundPosition), this.width / 2, this.height - 51, 0xFF65E572);
    }

    @Override
    public void onClose() {
        config.save();
        this.minecraft.setScreen(null);
    }
}
