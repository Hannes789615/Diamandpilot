package de.diamondpilot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Persistent settings and counters. Automation is deliberately not persisted as active. */
public final class DiamondPilotConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("diamondpilot.json");
    private static DiamondPilotConfig instance;

    public int searchRadius = 40;
    public int durabilityThreshold = 15;
    public boolean xrayEnabled = false;
    public long diamondsFound = 0;
    public long diamondBlocksMined = 0;
    public double distanceTravelled = 0;
    public long exploredAreas = 0;
    public long scannedBlockPositions = 0;
    public String lastPosition = "Unknown";
    public String lastFoundPosition = "Noch nichts gefunden";
    /** Packed BlockPos values and scanned-region keys, scoped to one server/world + dimension. */
    public List<String> foundDiamondPositions = new ArrayList<>();
    public Set<String> exploredRegionKeys = new HashSet<>();
    public String savedWorldKey = "";

    // Safety: never auto-resume after a restart.
    public transient boolean active = false;
    public transient boolean paused = false;
    public transient String status = "Stopped";

    private DiamondPilotConfig() {}

    public static DiamondPilotConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    private static DiamondPilotConfig load() {
        try {
            if (Files.exists(FILE)) {
                DiamondPilotConfig loaded = GSON.fromJson(Files.readString(FILE), DiamondPilotConfig.class);
                if (loaded != null) {
                    loaded.active = false;
                    loaded.paused = false;
                    loaded.status = "Stopped";
                    loaded.searchRadius = clamp(loaded.searchRadius, 8, 96);
                    loaded.durabilityThreshold = clamp(loaded.durabilityThreshold, 1, 100);
                    if (loaded.foundDiamondPositions == null) loaded.foundDiamondPositions = new ArrayList<>();
                    if (loaded.exploredRegionKeys == null) loaded.exploredRegionKeys = new HashSet<>();
                    return loaded;
                }
            }
        } catch (Exception ignored) {
            // A damaged config should not prevent Minecraft from starting.
        }
        return new DiamondPilotConfig();
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Path temp = FILE.resolveSibling(FILE.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(this));
            try {
                Files.move(temp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveUnsupported) {
                Files.move(temp, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            System.err.println("[DiamondPilot] Could not save config: " + exception.getMessage());
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
