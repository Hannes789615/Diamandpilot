package de.diamondpilot;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.client.Minecraft;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/** Incremental scan of block data already known to the client. It never accesses unloaded chunks. */
public final class DiamondScanner {
    private static final int VERTICAL_RADIUS = 16;
    // Bound per-tick work and total scan size to avoid multi-minute freezes at huge radii.
    private static final int BLOCKS_PER_TICK = 4096;
    private static final int MAX_RADIUS = 96;
    private final Set<BlockPos> found = new LinkedHashSet<>();
    private int centerX, centerY, centerZ, radius, index, volume;
    private boolean initialized;
    private boolean completed;
    private long scannedAreas;
    private int scanFound;
    private int loadedBlockCount;
    private int completedRefreshTicks;
    private String activeWorldKey = "";

    public void reset(Minecraft client, int requestedRadius) {
        if (client.player == null || client.level == null) return;
        ensureWorld(client, DiamondPilotConfig.get());
        radius = Math.max(8, Math.min(MAX_RADIUS, requestedRadius));
        BlockPos p = client.player.blockPosition();
        centerX = p.getX(); centerY = p.getY(); centerZ = p.getZ();
        int width = radius * 2 + 1;
        volume = width * width * (VERTICAL_RADIUS * 2 + 1);
        index = 0;
        scanFound = 0;
        loadedBlockCount = 0;
        initialized = true;
        completed = false;
    }

    public void tick(Minecraft client, DiamondPilotConfig config) {
        ensureWorld(client, config);
        if (!config.active || config.paused || client.player == null || client.level == null) return;
        BlockPos playerPos = client.player.blockPosition();
        if (radius != config.searchRadius ||
                Math.abs(playerPos.getX() - centerX) > Math.max(8, radius / 2) ||
                Math.abs(playerPos.getZ() - centerZ) > Math.max(8, radius / 2) ||
                Math.abs(playerPos.getY() - centerY) > 8) {
            reset(client, config.searchRadius);
        }
        if (completed) {
            // Chunks can become available after the first pass. Revisit the bounded
            // scan area periodically instead of permanently ignoring newly loaded data.
            if (++completedRefreshTicks < 100) return;
            completedRefreshTicks = 0;
            reset(client, config.searchRadius);
        }
        if (!initialized) reset(client, config.searchRadius);
        if (!initialized) return;
        int width = radius * 2 + 1;
        int end = Math.min(volume, index + BLOCKS_PER_TICK);
        for (; index < end; index++) {
            config.scannedBlockPositions++;
            int x = centerX - radius + index % width;
            int z = centerZ - radius + (index / width) % width;
            int y = centerY - VERTICAL_RADIUS + index / (width * width);
            BlockPos pos = new BlockPos(x, y, z);
            if (!client.level.hasChunkAt(pos)) continue;
            loadedBlockCount++;
            var state = client.level.getBlockState(pos);
            boolean diamondOre = state.is(Blocks.DIAMOND_ORE) || state.is(Blocks.DEEPSLATE_DIAMOND_ORE);
            if (!diamondOre && found.remove(pos)) {
                config.foundDiamondPositions.remove(Long.toString(pos.asLong()));
            }
            if (diamondOre) {
                scanFound++;
                if (found.add(pos.immutable())) {
                    String packed = Long.toString(pos.asLong());
                    config.foundDiamondPositions.add(packed);
                    // Bound both persistent and in-memory maps to prevent unbounded growth.
                    if (config.foundDiamondPositions.size() > 12000) {
                        String oldest = config.foundDiamondPositions.remove(0);
                        try { found.remove(BlockPos.of(Long.parseLong(oldest))); }
                        catch (NumberFormatException ignored) { /* discard malformed saved position */ }
                    }
                    config.diamondsFound++;
                    config.lastFoundPosition = x + ", " + y + ", " + z;
                    config.status = "Diamanterz gefunden: " + config.lastFoundPosition;
                }
            }
        }
        if (index >= volume) {
            scannedAreas++;
            // Count each loaded chunk/vertical section covered by this scan once.
            int minChunkX = Math.floorDiv(centerX - radius, 16);
            int maxChunkX = Math.floorDiv(centerX + radius, 16);
            int minChunkZ = Math.floorDiv(centerZ - radius, 16);
            int maxChunkZ = Math.floorDiv(centerZ + radius, 16);
            int sectionY = Math.floorDiv(centerY, 16);
            for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
                for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
                    BlockPos sample = new BlockPos(chunkX * 16, centerY, chunkZ * 16);
                    if (!client.level.hasChunkAt(sample)) continue;
                    String regionKey = chunkX + ":" + chunkZ + ":" + sectionY;
                    if (config.exploredRegionKeys.add(regionKey)) config.exploredAreas++;
                }
            }
            // Keep persisted region history bounded on very long sessions.
            while (config.exploredRegionKeys.size() > 5000) {
                var iterator = config.exploredRegionKeys.iterator();
                if (!iterator.hasNext()) break;
                iterator.next();
                iterator.remove();
            }
            initialized = false;
            completed = true;
            completedRefreshTicks = 0;
            // Do not expand the radius merely because most of the requested volume
            // was in unloaded chunks. Wait for newly loaded client data and rescan.
            double loadedCoverage = volume == 0 ? 0.0 : (double) loadedBlockCount / volume;
            if (scanFound == 0 && loadedCoverage >= 0.25 && radius < MAX_RADIUS) {
                config.searchRadius = Math.min(MAX_RADIUS, radius + 8);
                config.status = "Kein Diamanterz im Bereich – Radius wird auf " + config.searchRadius + " erweitert";
                config.save();
                reset(client, config.searchRadius);
            } else {
                config.status = scanFound == 0
                        ? (loadedCoverage < 0.25
                            ? "Zu wenig Bereich geladen – warte auf neue Chunks und prüfe erneut"
                            : "Geladener Bereich geprüft – keine Diamanten gefunden (Radiusmaximum ggf. erreicht)")
                        : "Scan abgeschlossen – Diamanterzpositionen gespeichert";
                config.save();
            }
        }
    }

    private void ensureWorld(Minecraft client, DiamondPilotConfig config) {
        if (client.level == null) return;
        String server;
        if (client.getCurrentServer() != null) {
            server = "server:" + client.getCurrentServer().ip;
        } else {
            var integratedServer = client.getSingleplayerServer();
            String worldName = integratedServer == null ? "singleplayer-unknown"
                    : integratedServer.getWorldData().getLevelName();
            server = "singleplayer:" + worldName;
        }
        String key = server + "|" + client.level.dimension().toString();
        if (key.equals(activeWorldKey)) return;
        activeWorldKey = key;
        if (!key.equals(config.savedWorldKey)) {
            config.foundDiamondPositions.clear();
            config.exploredRegionKeys.clear();
            config.savedWorldKey = key;
            config.save();
        }
        found.clear();
        for (String packed : config.foundDiamondPositions) {
            try { found.add(BlockPos.of(Long.parseLong(packed))); }
            catch (NumberFormatException ignored) { /* discard malformed saved positions */ }
        }
    }

    public void forget(BlockPos pos, DiamondPilotConfig config) {
        found.remove(pos);
        config.foundDiamondPositions.remove(Long.toString(pos.asLong()));
    }

    public Set<BlockPos> foundBlocks() { return Collections.unmodifiableSet(found); }
    public BlockPos nearestTo(BlockPos from) {
        BlockPos best = null; double distance = Double.MAX_VALUE;
        for (BlockPos p : found) {
            double d = p.distToCenterSqr(from.getX() + .5, from.getY() + .5, from.getZ() + .5);
            if (d < distance) { distance = d; best = p; }
        }
        return best;
    }
    public int foundCount() { return found.size(); }
}
