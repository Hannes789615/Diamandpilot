package de.diamondpilot.mixin;

import de.diamondpilot.DiamondPilotConfig;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Client-only render override: hide ordinary block models while X-Ray is enabled. */
@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class BlockStateRenderMixin {
    @Inject(method = "getRenderShape", at = @At("HEAD"), cancellable = true)
    private void diamondpilot$hideNormalBlocks(CallbackInfoReturnable<RenderShape> cir) {
        if (diamondpilot$shouldHide((BlockState) (Object) this)) {
            cir.setReturnValue(RenderShape.INVISIBLE);
        }
    }

    // Disable occlusion from hidden blocks; otherwise their neighbors can still hide ore faces.
    @Inject(method = "isSolidRender", at = @At("HEAD"), cancellable = true)
    private void diamondpilot$disableOcclusion(BlockGetter level, BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (diamondpilot$shouldHide((BlockState) (Object) this)) cir.setReturnValue(false);
    }

    @Inject(method = "getLightBlock", at = @At("HEAD"), cancellable = true)
    private void diamondpilot$reduceLightOcclusion(BlockGetter level, BlockPos pos, CallbackInfoReturnable<Integer> cir) {
        if (diamondpilot$shouldHide((BlockState) (Object) this)) cir.setReturnValue(0);
    }

    private static boolean diamondpilot$shouldHide(BlockState state) {
        if (!DiamondPilotConfig.get().xrayEnabled) return false;
        // Keep diamond ore, bedrock, fluids, and block entities visible for target and hazard awareness.
        return !state.isAir()
                && !state.is(Blocks.DIAMOND_ORE)
                && !state.is(Blocks.DEEPSLATE_DIAMOND_ORE)
                && !state.is(Blocks.BEDROCK)
                && !state.is(Blocks.WATER)
                && !state.is(Blocks.LAVA)
                && state.getFluidState().isEmpty()
                && !state.hasBlockEntity();
    }
}
