package de.diamondpilot;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class DiamondPilotClient implements ClientModInitializer {
    public static final String MOD_ID = "diamondpilot";
    public static final DiamondScanner SCANNER = new DiamondScanner();
    public static final DiamondPilotAutomation AUTOMATION = new DiamondPilotAutomation();
    private static KeyMapping openMenuKey;
    private static net.minecraft.core.BlockPos lastTickPosition;
    private static int saveTickCounter;

    @Override
    public void onInitializeClient() {
        DiamondPilotConfig config = DiamondPilotConfig.get();
        config.active = false;
        config.paused = false;
        config.status = "Stopped";

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "controls"));
        openMenuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.diamondpilot.open_menu", InputConstants.Type.KEYBOARD, InputConstants.KEY_J, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.player != null) {
                    // The single configured hotkey toggles the panel instead of stacking screens.
                    if (client.screen instanceof DiamondPilotScreen) client.setScreen(null);
                    else client.setScreen(new DiamondPilotScreen());
                }
            }
            if (client.player == null || client.level == null) {
                if (config.active || config.paused) {
                    AUTOMATION.stop(client, config, "Gestoppt – Verbindung getrennt");
                }
                lastTickPosition = null;
                return;
            }

            net.minecraft.core.BlockPos current = client.player.blockPosition();
            if (lastTickPosition != null && config.active && !config.paused) {
                double dx = current.getX() - lastTickPosition.getX();
                double dy = current.getY() - lastTickPosition.getY();
                double dz = current.getZ() - lastTickPosition.getZ();
                double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (distance > 0) config.distanceTravelled += distance;
            }
            lastTickPosition = current.immutable();
            // Persist progress periodically without writing the config file every game tick.
            if (++saveTickCounter >= 100) {
                saveTickCounter = 0;
                config.save();
            }

            if (config.active && !config.paused) {
                AUTOMATION.tick(client, config, SCANNER);
                if (client.player != null) {
                    config.lastPosition = client.player.blockPosition().toShortString();
                }
            } else {
                AUTOMATION.releaseInputs(client);
            }
        });
    }
}
