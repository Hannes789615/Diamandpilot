#!/usr/bin/env python3
"""Offline structural checks for DiamondPilot; this is not a Minecraft build/test."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
required = [
    ROOT / "build.gradle",
    ROOT / "gradle.properties",
    ROOT / "settings.gradle",
    ROOT / "src/main/resources/fabric.mod.json",
    ROOT / "src/main/java/de/diamondpilot/DiamondPilotClient.java",
    ROOT / "src/main/java/de/diamondpilot/DiamondPilotConfig.java",
    ROOT / "src/main/java/de/diamondpilot/DiamondScanner.java",
    ROOT / "src/main/java/de/diamondpilot/DiamondPilotAutomation.java",
    ROOT / "src/main/java/de/diamondpilot/DiamondPilotScreen.java",
    ROOT / "src/main/java/de/diamondpilot/mixin/BlockStateRenderMixin.java",
    ROOT / "src/main/resources/diamondpilot.mixins.json",
    ROOT / ".github/workflows/build.yml",
]
missing = [str(p.relative_to(ROOT)) for p in required if not p.is_file()]
if missing:
    print("FAIL missing files:", ", ".join(missing))
    sys.exit(1)

try:
    metadata = json.loads((ROOT / "src/main/resources/fabric.mod.json").read_text())
except Exception as exc:
    print("FAIL fabric.mod.json:", exc)
    sys.exit(1)
if metadata.get("id") != "diamondpilot" or metadata.get("environment") != "client":
    print("FAIL mod metadata id/environment")
    sys.exit(1)

props = dict(line.split("=", 1) for line in (ROOT / "gradle.properties").read_text().splitlines()
             if line.strip() and not line.lstrip().startswith("#") and "=" in line)
if props.get("minecraft_version") != "26.3":
    print("FAIL unexpected Minecraft version:", props.get("minecraft_version"))
    sys.exit(1)

source = "\n".join(p.read_text() for p in required if p.suffix == ".java")
checks = {
    "default J hotkey": "InputConstants.KEY_J" in source,
    "start/pause/stop controls": all(x in source for x in ['"Start"', '"STOP sofort"', '"Pause"']),
    "stays inactive after restart": "config.active = false" in source,
    "diamond ore scanning": "Blocks.DIAMOND_ORE" in source and "Blocks.DEEPSLATE_DIAMOND_ORE" in source,
    "fluid safety": "hasFluidHazard" in source,
    "durability threshold": "durabilityThreshold" in source,
    "persisted ore positions": "foundDiamondPositions" in source,
    "world-scoped cache": "savedWorldKey" in source,
    "stuck-turn recovery": "Feststecken erkannt" in source,
    "safe retreat checks": "kein sicherer Rückweg" in source,
    "cardinal tunnel alignment": "tunnelDirection.toYRot()" in source,
    "uses Minecraft screen API": "gui.setScreen" not in source and ".setScreen(" in source,
    "X-Ray menu toggle": "toggleXray()" in source and "X-Ray: AN" in source,
    "X-Ray render mixin": "RenderShape.INVISIBLE" in (ROOT / "src/main/java/de/diamondpilot/mixin/BlockStateRenderMixin.java").read_text(),
    "J hotkey toggles menu": "client.screen instanceof DiamondPilotScreen" in (ROOT / "src/main/java/de/diamondpilot/DiamondPilotClient.java").read_text(),
    "X-Ray refreshes chunk rendering": "levelRenderer.allChanged()" in (ROOT / "src/main/java/de/diamondpilot/DiamondPilotScreen.java").read_text(),
    "scanner revisits newly loaded chunks": "completedRefreshTicks" in (ROOT / "src/main/java/de/diamondpilot/DiamondScanner.java").read_text(),
    "singleplayer caches are world-scoped": 'getWorldData().getLevelName()' in (ROOT / "src/main/java/de/diamondpilot/DiamondScanner.java").read_text(),
    "monster retreat follows checked direction": "player.setYRot(retreatDirection.toYRot())" in (ROOT / "src/main/java/de/diamondpilot/DiamondPilotAutomation.java").read_text(),
    "direct mining checks line of sight": "canSeeTargetBlock(client, diamond)" in (ROOT / "src/main/java/de/diamondpilot/DiamondPilotAutomation.java").read_text(),
    "uses Minecraft 26.3 Loom line": "1.18-SNAPSHOT" in (ROOT / "build.gradle").read_text(),
    "build workflow uses Java 25": "java-version: '25'" in (ROOT / ".github/workflows/build.yml").read_text(),
    "build workflow uses Gradle 9.7.1": "gradle-version: '9.7.1'" in (ROOT / ".github/workflows/build.yml").read_text(),
    "build workflow packages a JAR": "gradle --no-daemon clean build" in (ROOT / ".github/workflows/build.yml").read_text(),
    "version updated to 0.17.0": props.get("mod_version") == "0.17.0",
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS " if ok else "FAIL ") + name)
if failed:
    sys.exit(1)
print("\nStructural checks passed. This does NOT prove Java compilation or in-game behavior.")
